
#ifndef __SYSTEM_H
#define __SYSTEM_H


/**********************************************************
** appel du systeme
***********************************************************/

PSW systeme(PSW m);
PSW systeme_init_boucle(void);

#endif
